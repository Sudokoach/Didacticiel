import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class TilesRotation1 extends PApplet {


PImage tile;
float angle, tw, th, s, c, dx, dy;
public void setup() {
  
  tile=loadImage("tileimage.png");
  tile.loadPixels();
  tw = tile.width;
  th = tile.height;
  angle = 0;
  dx=sqrt(2)/2;dx=0.5f;
  dy=dx;
 frameRate(23);
}

public void draw() {
  background(0);
  s = sin(angle);
  c = cos(angle);
  angle += 0.013f;
  angle=angle%(2*PI);

  loadPixels();

  for (int row=0; row<5; row++) {
    for (int col=0; col<5; col++) {
      for (float y=row*th+1; y<(row+1)*th-1; y+=dx) {
        for (float x=col*tw+1; x<(col+1)*tw-1; x+=dy) {
          int rx=round(width/2+(x-5*tw/2)*c+(y-5*th/2)*s);
          int ry=round(height/2-(x-5*tw/2)*s+(y-5*th/2)*c);
          pixels[rx+ry*width]=tile.get(round(x%tw), round(y%th));
        }
      }
    }
  }

  updatePixels();
}
  public void settings() {  size(511, 511); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "TilesRotation1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
